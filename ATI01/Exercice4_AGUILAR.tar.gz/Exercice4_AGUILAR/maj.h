#ifndef MAJ_C
#define MAJ_C

int min(unsigned char chaine[100]);

typedef struct point_s {
    unsigned char* chain;
} point_t ;

#endif
