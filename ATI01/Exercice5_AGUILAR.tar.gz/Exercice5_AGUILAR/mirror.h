#ifndef MIRROR_H
#define MIRROR_H

int mirror(unsigned char*, int);

typedef struct point_s {
    
    unsigned char* chain;

}point_t;


#endif
