#ifndef PALL_H
#define PALL_H

int pall(unsigned char*, int);

typedef struct point_s {
    
    unsigned char* chain;

}point_t;


#endif
